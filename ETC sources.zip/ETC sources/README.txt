- public_html contains the code for the new website.
	The contents of public_html should be uploaded to
	the public_html directory on the server being used
	to host the website.

- mySQL contains a script to set up the database for
	the website. Run the contents of mySQL as query
	on a (preferably empty) mySQL database to set it 
	up.

- login_info contains text files with the login info
	for:
		- the 000webhost currently hosting the website
		- the Doteasy host currently used by ETC
		- the namecheap account holding the enterna.me
			domain name

- DonationForm is word document used to generate
	DonationForm.pdf for entities wanting to donate by
	mail